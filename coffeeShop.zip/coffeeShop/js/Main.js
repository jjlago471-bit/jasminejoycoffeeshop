// ─── MENU DATA ───────────────────────────────────────────────────────────────
const menuItems = [
  { id: 1, name: 'Espresso',          price: 120, tag: 'Single Origin', img: 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=200&q=80' },
  { id: 2, name: 'Cappuccino',        price: 160, tag: 'Most Popular',  img: 'https://images.unsplash.com/photo-1534778101976-62847782c213?w=200&q=80' },
  { id: 3, name: 'Iced Coffee',       price: 175, tag: 'Signature',     img: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=200&q=80' },
  { id: 4, name: 'Cold Brew',         price: 195, tag: 'Slow Brewed',   img: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=200&q=80' },
  { id: 5, name: 'Caramel Macchiato', price: 185, tag: 'Fan Favorite',  img: 'https://images.unsplash.com/photo-1529892485617-25f63cd7b1e9?w=200&q=80' },
  { id: 6, name: 'Matcha Flat White', price: 210, tag: 'Seasonal',      img: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=200&q=80' },
];

// ─── CART STATE ──────────────────────────────────────────────────────────────
let cart = [];
let currentStep = 1;
let orderType = 'dine-in';

// ─── CREATE MODAL HTML ───────────────────────────────────────────────────────
function createModal() {
  const modal = document.createElement('div');
  modal.id = 'order-modal';
  modal.innerHTML = `
    <div class="modal-backdrop" id="modal-backdrop"></div>
    <div class="modal-panel" id="modal-panel">

      <div class="modal-header">
        <div>
          <h2 class="modal-title">Make an Order</h2>
          <p class="modal-sub">Fresh, handcrafted just for you</p>
        </div>
        <button class="modal-close" id="modal-close">✕</button>
      </div>

      <div class="modal-steps-bar">
        <div class="modal-step-dot active" id="dot-1">1</div>
        <div class="modal-step-line"></div>
        <div class="modal-step-dot" id="dot-2">2</div>
        <div class="modal-step-line"></div>
        <div class="modal-step-dot" id="dot-3">3</div>
      </div>

      <div class="modal-body">

        <!-- STEP 1: MENU PICKER -->
        <div class="modal-step-content" id="step-1">
          <p class="step-label">Select your drinks</p>
          <div class="modal-menu-grid" id="modal-menu-grid"></div>
        </div>

        <!-- STEP 2: CART REVIEW -->
        <div class="modal-step-content hidden" id="step-2">
          <p class="step-label">Review your order</p>
          <div class="modal-cart" id="modal-cart"></div>
          <div class="cart-summary" id="cart-summary"></div>
        </div>

        <!-- STEP 3: DETAILS -->
        <div class="modal-step-content hidden" id="step-3">
          <p class="step-label">Your details</p>
          <div class="order-form">
            <div class="form-group">
              <label>Full Name</label>
              <input type="text" id="order-name" placeholder="e.g. Maria Santos" />
            </div>
            <div class="form-group">
              <label>Phone Number</label>
              <input type="tel" id="order-phone" placeholder="e.g. 09XX XXX XXXX" />
            </div>
            <div class="form-group">
              <label>Order Type</label>
              <div class="order-type-btns">
                <button class="type-btn active" data-type="dine-in">🪑 Dine In</button>
                <button class="type-btn" data-type="takeout">🛍 Takeout</button>
                <button class="type-btn" data-type="delivery">🛵 Delivery</button>
              </div>
            </div>
            <div class="form-group" id="address-group" style="display:none;">
              <label>Delivery Address</label>
              <input type="text" id="order-address" placeholder="Street, Barangay, Cebu City" />
            </div>
            <div class="form-group">
              <label>Special Instructions <span class="optional">(optional)</span></label>
              <textarea id="order-notes" placeholder="e.g. Less sugar, extra hot, no ice..."></textarea>
            </div>
          </div>
        </div>

        <!-- STEP 4: SUCCESS -->
        <div class="modal-step-content hidden" id="step-4">
          <div class="order-success">
            <div class="success-icon">☕</div>
            <h3>Order Placed!</h3>
            <p id="success-msg"></p>
            <div class="success-order-summary" id="success-summary"></div>
            <p class="success-note">We'll prepare your order shortly.<br>Thank you for choosing BREWNI! 🙌</p>
            <button class="modal-btn-next" id="btn-close-success" style="margin-top:1.5rem;">Done</button>
          </div>
        </div>

      </div>

      <!-- FOOTER -->
      <div class="modal-footer" id="modal-footer">
        <button class="modal-btn-back hidden" id="btn-back">← Back</button>
        <div class="footer-right">
          <span class="cart-count-label" id="cart-count-label"></span>
          <button class="modal-btn-next" id="btn-next">View Cart →</button>
        </div>
      </div>

    </div>
  `;
  document.body.appendChild(modal);
}

// ─── RENDER MENU GRID ────────────────────────────────────────────────────────
function renderMenuGrid() {
  const grid = document.getElementById('modal-menu-grid');
  grid.innerHTML = menuItems.map(item => `
    <div class="modal-menu-card" id="card-${item.id}">
      <img src="${item.img}" alt="${item.name}" class="modal-menu-img" />
      <div class="modal-menu-info">
        <span class="modal-menu-name">${item.name}</span>
        <span class="modal-menu-price">₱${item.price}</span>
      </div>
      <div class="modal-qty-row">
        <button class="qty-btn minus" data-id="${item.id}">−</button>
        <span class="qty-display" id="qty-${item.id}">0</span>
        <button class="qty-btn plus" data-id="${item.id}">+</button>
      </div>
    </div>
  `).join('');

  grid.querySelectorAll('.qty-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      const item = menuItems.find(m => m.id === id);
      const inCart = cart.find(c => c.id === id);
      if (btn.classList.contains('plus')) {
        if (inCart) inCart.qty++;
        else cart.push({ ...item, qty: 1 });
      } else {
        if (inCart && inCart.qty > 0) {
          inCart.qty--;
          if (inCart.qty === 0) cart = cart.filter(c => c.id !== id);
        }
      }
      updateQtyDisplay(id);
      updateCartCountLabel();
    });
  });
}

function updateQtyDisplay(id) {
  const inCart = cart.find(c => c.id === id);
  const qty = inCart ? inCart.qty : 0;
  const el = document.getElementById(`qty-${id}`);
  if (el) el.textContent = qty;
  const card = document.getElementById(`card-${id}`);
  if (card) card.classList.toggle('in-cart', qty > 0);
}

function updateCartCountLabel() {
  const total = cart.reduce((s, c) => s + c.qty, 0);
  const label = document.getElementById('cart-count-label');
  if (label) label.textContent = total > 0 ? `${total} item${total > 1 ? 's' : ''} selected` : '';
}

// ─── RENDER CART ─────────────────────────────────────────────────────────────
function renderCart() {
  const cartEl = document.getElementById('modal-cart');
  const summaryEl = document.getElementById('cart-summary');

  if (cart.length === 0) {
    cartEl.innerHTML = '<p class="empty-cart">Your cart is empty. Go back to add items.</p>';
    summaryEl.innerHTML = '';
    return;
  }

  cartEl.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img src="${item.img}" alt="${item.name}" class="cart-item-img" />
      <div class="cart-item-info">
        <span class="cart-item-name">${item.name}</span>
        <span class="cart-item-unit">₱${item.price} each</span>
      </div>
      <div class="cart-item-qty-row">
        <button class="qty-btn minus" data-id="${item.id}">−</button>
        <span>${item.qty}</span>
        <button class="qty-btn plus" data-id="${item.id}">+</button>
      </div>
      <span class="cart-item-total">₱${item.price * item.qty}</span>
    </div>
  `).join('');

  const subtotal = cart.reduce((s, c) => s + c.price * c.qty, 0);
  summaryEl.innerHTML = `
    <div class="summary-row"><span>Subtotal</span><span>₱${subtotal}</span></div>
    <div class="summary-row"><span>Service Fee</span><span>₱20</span></div>
    <div class="summary-row total"><span>Total</span><span>₱${subtotal + 20}</span></div>
  `;

  cartEl.querySelectorAll('.qty-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      const inCart = cart.find(c => c.id === id);
      if (btn.classList.contains('plus')) { inCart.qty++; }
      else {
        inCart.qty--;
        if (inCart.qty === 0) cart = cart.filter(c => c.id !== id);
      }
      renderCart();
      updateCartCountLabel();
    });
  });
}

// ─── STEP NAVIGATION ─────────────────────────────────────────────────────────
function updateStepDots(step) {
  [1, 2, 3].forEach(n => {
    const dot = document.getElementById(`dot-${n}`);
    if (!dot) return;
    dot.classList.remove('active', 'done');
    if (n < step) dot.classList.add('done');
    else if (n === step) dot.classList.add('active');
  });
}

function goToStep(step) {
  document.querySelectorAll('.modal-step-content').forEach(s => s.classList.add('hidden'));
  document.getElementById(`step-${step}`).classList.remove('hidden');
  currentStep = step;
  updateStepDots(step);

  const btnBack = document.getElementById('btn-back');
  const btnNext = document.getElementById('btn-next');
  const footer  = document.getElementById('modal-footer');

  btnBack.classList.toggle('hidden', step === 1);

  if (step === 1) {
    footer.style.display = 'flex';
    btnNext.style.display = 'inline-block';
    btnNext.textContent = 'View Cart →';
    updateCartCountLabel();
  } else if (step === 2) {
    renderCart();
    btnNext.textContent = 'Continue →';
    updateCartCountLabel();
  } else if (step === 3) {
    btnNext.textContent = 'Place Order ☕';
    document.getElementById('cart-count-label').textContent = '';
  } else if (step === 4) {
    footer.style.display = 'none';
  }
}

// ─── PLACE ORDER ─────────────────────────────────────────────────────────────
function placeOrder() {
  const name  = document.getElementById('order-name').value.trim();
  const phone = document.getElementById('order-phone').value.trim();
  if (!name || !phone) { alert('Please fill in your name and phone number.'); return; }

  const subtotal  = cart.reduce((s, c) => s + c.price * c.qty, 0);
  const total     = subtotal + 20;
  const itemLines = cart.map(c => `<div class="si-row"><span>${c.name} x${c.qty}</span><span>₱${c.price * c.qty}</span></div>`).join('');

  document.getElementById('success-msg').textContent =
    `Hi ${name}! Your ${orderType.replace('-', ' ')} order has been received.`;

  document.getElementById('success-summary').innerHTML = `
    ${itemLines}
    <div class="si-row si-total"><span>Total</span><span>₱${total}</span></div>
  `;

  goToStep(4);
  cart = [];
}

// ─── OPEN / CLOSE ─────────────────────────────────────────────────────────────
function openModal() {
  cart = [];
  currentStep = 1;
  document.getElementById('order-modal').classList.add('active');
  document.body.style.overflow = 'hidden';
  renderMenuGrid();
  updateCartCountLabel();
  goToStep(1);
}

function closeModal() {
  document.getElementById('order-modal').classList.remove('active');
  document.body.style.overflow = '';
}

// ─── INIT ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  createModal();

  document.querySelector('.nav-cta').addEventListener('click', openModal);

  document.querySelectorAll('a[href="#order"], .btn-dark').forEach(btn => {
    btn.addEventListener('click', (e) => { e.preventDefault(); openModal(); });
  });

  document.getElementById('modal-close').addEventListener('click', closeModal);
  document.getElementById('modal-backdrop').addEventListener('click', closeModal);

  document.getElementById('btn-next').addEventListener('click', () => {
    if (currentStep === 1) {
      if (cart.length === 0) { alert('Please add at least one item to your cart.'); return; }
      goToStep(2);
    } else if (currentStep === 2) {
      if (cart.length === 0) { alert('Your cart is empty.'); return; }
      goToStep(3);
    } else if (currentStep === 3) {
      placeOrder();
    }
  });

  document.getElementById('btn-back').addEventListener('click', () => {
    if (currentStep > 1) goToStep(currentStep - 1);
  });

  document.addEventListener('click', (e) => {
    if (e.target.id === 'btn-close-success') closeModal();

    if (e.target.classList.contains('type-btn')) {
      document.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      orderType = e.target.dataset.type;
      const ag = document.getElementById('address-group');
      if (ag) ag.style.display = orderType === 'delivery' ? 'flex' : 'none';
    }
  });

  // ── existing page scripts ────────────────────────────────────────────────

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
  }, { threshold: 0.12 });
  document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right').forEach(el => observer.observe(el));

  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  document.querySelectorAll('.add-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      this.textContent = '✓';
      this.style.background = '#3d7a52';
      this.style.color = 'white';
      setTimeout(() => { this.textContent = '+'; this.style.background = ''; this.style.color = ''; }, 1500);
    });
  });

  window.addEventListener('scroll', () => {
    const nav = document.querySelector('nav');
    nav.style.padding = window.scrollY > 60 ? '0.8rem 4rem' : '1.2rem 4rem';
  });

  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const today = days[new Date().getDay()];
  document.querySelectorAll('.hours-row').forEach(row => {
    row.classList.remove('today');
    if (row.querySelector('.day').textContent.trim().startsWith(today)) {
      row.classList.add('today');
      const badge = document.createElement('span');
      badge.className = 'today-badge';
      badge.textContent = 'Today';
      if (!row.querySelector('.today-badge')) row.querySelector('.day').appendChild(badge);
    }
  });
});