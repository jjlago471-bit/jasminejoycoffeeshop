// ─── MENU DATA ───────────────────────────────────────────────────────────────
const menuItems = [
  { id: 1, cat: 'espresso', name: 'Espresso',          price: 120, img: 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=200&q=80' },
  { id: 2, cat: 'espresso', name: 'Cappuccino',        price: 160, img: 'https://images.unsplash.com/photo-1534778101976-62847782c213?w=200&q=80' },
  { id: 3, cat: 'cold',     name: 'Iced Coffee',       price: 175, img: 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=200&q=80' },
  { id: 4, cat: 'cold',     name: 'Cold Brew',         price: 195, img: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=200&q=80' },
  { id: 5, cat: 'espresso', name: 'Caramel Macchiato', price: 185, img: 'https://images.unsplash.com/photo-1529892485617-25f63cd7b1e9?w=200&q=80' },
  { id: 6, cat: 'seasonal', name: 'Matcha Flat White', price: 210, img: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=200&q=80' },
];
const SERVICE_FEE = 20;

// ─── STATE ───────────────────────────────────────────────────────────────────
let cart = [];
let currentStep = 1;
let orderType = 'dine-in';
let lastFocus = null;

const $ = (id) => document.getElementById(id);
const qtyOf = (id) => (cart.find(c => c.id === id) || { qty: 0 }).qty;
const subtotal = () => cart.reduce((s, c) => s + c.price * c.qty, 0);

function changeQty(id, delta) {
  const item = menuItems.find(m => m.id === id);
  if (!item) return;
  const inCart = cart.find(c => c.id === id);
  if (inCart) {
    inCart.qty += delta;
    if (inCart.qty <= 0) cart = cart.filter(c => c.id !== id);
  } else if (delta > 0) {
    cart.push({ ...item, qty: 1 });
  }
  updateCartCountLabel();
}

// ─── MODAL HTML ──────────────────────────────────────────────────────────────
function createModal() {
  const modal = document.createElement('div');
  modal.id = 'order-modal';
  modal.innerHTML = `
    <div class="modal-backdrop" id="modal-backdrop"></div>
    <div class="modal-panel" id="modal-panel" role="dialog" aria-modal="true" aria-labelledby="modal-title">
      <div class="modal-header">
        <div>
          <h2 class="modal-title" id="modal-title">Make an Order</h2>
          <p class="modal-sub">Fresh, handcrafted just for you</p>
        </div>
        <button class="modal-close" id="modal-close" aria-label="Close order window">✕</button>
      </div>

      <div class="modal-steps-bar">
        <div class="modal-step-dot active" id="dot-1">1</div>
        <div class="modal-step-line"></div>
        <div class="modal-step-dot" id="dot-2">2</div>
        <div class="modal-step-line"></div>
        <div class="modal-step-dot" id="dot-3">3</div>
      </div>

      <div class="modal-body">
        <div class="modal-step-content" id="step-1">
          <p class="step-label">Select your drinks</p>
          <div class="modal-menu-grid" id="modal-menu-grid"></div>
        </div>

        <div class="modal-step-content hidden" id="step-2">
          <p class="step-label">Review your order</p>
          <div class="modal-cart" id="modal-cart"></div>
          <div class="cart-summary" id="cart-summary"></div>
        </div>

        <div class="modal-step-content hidden" id="step-3">
          <p class="step-label">Your details</p>
          <div class="order-form">
            <div class="form-group">
              <label for="order-name">Full Name</label>
              <input type="text" id="order-name" placeholder="e.g. Maria Santos" autocomplete="name" />
            </div>
            <div class="form-group">
              <label for="order-phone">Phone Number</label>
              <input type="tel" id="order-phone" placeholder="e.g. 09XX XXX XXXX" autocomplete="tel" />
            </div>
            <div class="form-group">
              <label>Order Type</label>
              <div class="order-type-btns">
                <button type="button" class="type-btn active" data-type="dine-in">🪑 Dine In</button>
                <button type="button" class="type-btn" data-type="takeout">🛍 Takeout</button>
                <button type="button" class="type-btn" data-type="delivery">🛵 Delivery</button>
              </div>
            </div>
            <div class="form-group" id="address-group" style="display:none;">
              <label for="order-address">Delivery Address</label>
              <input type="text" id="order-address" placeholder="Street, Barangay, Cebu City" autocomplete="street-address" />
            </div>
            <div class="form-group">
              <label for="order-notes">Special Instructions <span class="optional">(optional)</span></label>
              <textarea id="order-notes" placeholder="e.g. Less sugar, extra hot, no ice..."></textarea>
            </div>
            <p class="form-error" id="form-error" role="alert"></p>
          </div>
        </div>

        <div class="modal-step-content hidden" id="step-4">
          <div class="order-success">
            <div class="success-icon">☕</div>
            <h3>Order Placed!</h3>
            <p id="success-msg"></p>
            <div class="success-order-summary" id="success-summary"></div>
            <p class="success-note">We'll prepare your order shortly.<br>Thank you for choosing BREWNI! 🙌</p>
            <button class="modal-btn-next" id="btn-close-success" style="margin-top:1.5rem;">Done</button>
          </div>
        </div>
      </div>

      <div class="modal-footer" id="modal-footer">
        <button class="modal-btn-back hidden" id="btn-back">← Back</button>
        <div class="footer-right">
          <span class="cart-count-label" id="cart-count-label"></span>
          <button class="modal-btn-next" id="btn-next">View Cart →</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(modal);
}

// ─── RENDERERS ───────────────────────────────────────────────────────────────
function renderMenuGrid() {
  $('modal-menu-grid').innerHTML = menuItems.map(item => {
    const q = qtyOf(item.id);
    return `
    <div class="modal-menu-card${q > 0 ? ' in-cart' : ''}" id="card-${item.id}">
      <img src="${item.img}" alt="${item.name}" class="modal-menu-img" />
      <div class="modal-menu-info">
        <span class="modal-menu-name">${item.name}</span>
        <span class="modal-menu-price">₱${item.price}</span>
      </div>
      <div class="modal-qty-row">
        <button class="qty-btn minus" data-id="${item.id}" aria-label="Remove one ${item.name}">−</button>
        <span class="qty-display" id="qty-${item.id}">${q}</span>
        <button class="qty-btn plus" data-id="${item.id}" aria-label="Add one ${item.name}">+</button>
      </div>
    </div>`;
  }).join('');
}

function updateQtyDisplay(id) {
  const q = qtyOf(id);
  const el = $(`qty-${id}`);
  if (el) el.textContent = q;
  const card = $(`card-${id}`);
  if (card) card.classList.toggle('in-cart', q > 0);
}

function updateCartCountLabel() {
  const total = cart.reduce((s, c) => s + c.qty, 0);
  const label = $('cart-count-label');
  if (label && currentStep < 3) label.textContent = total > 0 ? `${total} item${total > 1 ? 's' : ''} selected` : '';
  const navBtn = document.querySelector('.nav-cta');
  if (navBtn) navBtn.textContent = total > 0 ? `Make Order (${total})` : 'Make Order';
}

function renderCart() {
  const cartEl = $('modal-cart');
  const summaryEl = $('cart-summary');
  if (cart.length === 0) {
    cartEl.innerHTML = '<p class="empty-cart">Your cart is empty. Go back to add items.</p>';
    summaryEl.innerHTML = '';
    return;
  }
  cartEl.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img src="${item.img}" alt="${item.name}" class="cart-item-img" />
      <div class="cart-item-info">
        <span class="cart-item-name">${item.name}</span>
        <span class="cart-item-unit">₱${item.price} each</span>
      </div>
      <div class="cart-item-qty-row">
        <button class="qty-btn minus" data-id="${item.id}" aria-label="Remove one ${item.name}">−</button>
        <span>${item.qty}</span>
        <button class="qty-btn plus" data-id="${item.id}" aria-label="Add one ${item.name}">+</button>
      </div>
      <span class="cart-item-total">₱${item.price * item.qty}</span>
    </div>`).join('');
  const sub = subtotal();
  summaryEl.innerHTML = `
    <div class="summary-row"><span>Subtotal</span><span>₱${sub}</span></div>
    <div class="summary-row"><span>Service Fee</span><span>₱${SERVICE_FEE}</span></div>
    <div class="summary-row total"><span>Total</span><span>₱${sub + SERVICE_FEE}</span></div>`;
}

// ─── STEP NAVIGATION ─────────────────────────────────────────────────────────
function goToStep(step) {
  document.querySelectorAll('.modal-step-content').forEach(s => s.classList.add('hidden'));
  $(`step-${step}`).classList.remove('hidden');
  currentStep = step;

  [1, 2, 3].forEach(n => {
    const dot = $(`dot-${n}`);
    dot.classList.remove('active', 'done');
    if (n < step) dot.classList.add('done');
    else if (n === step) dot.classList.add('active');
  });

  const btnNext = $('btn-next');
  const footer = $('modal-footer');
  $('btn-back').classList.toggle('hidden', step === 1);
  $('form-error').textContent = '';
  footer.style.display = step === 4 ? 'none' : 'flex';
  $('cart-count-label').textContent = '';

  if (step === 1) { renderMenuGrid(); btnNext.textContent = 'View Cart →'; }
  else if (step === 2) { renderCart(); btnNext.textContent = 'Continue →'; }
  else if (step === 3) { btnNext.textContent = 'Place Order ☕'; }
  updateCartCountLabel();
  $('modal-panel').querySelector('.modal-body').scrollTop = 0;
}

// ─── PLACE ORDER ─────────────────────────────────────────────────────────────
function placeOrder() {
  const name = $('order-name').value.trim();
  const phone = $('order-phone').value.trim();
  const address = $('order-address').value.trim();
  const err = $('form-error');

  if (!name || !phone) { err.textContent = 'Please fill in your name and phone number.'; return; }
  if (phone.replace(/\D/g, '').length < 7) { err.textContent = 'Please enter a valid phone number.'; $('order-phone').focus(); return; }
  if (orderType === 'delivery' && !address) { err.textContent = 'Please enter your delivery address.'; $('order-address').focus(); return; }

  const total = subtotal() + SERVICE_FEE;
  const itemLines = cart.map(c => `<div class="si-row"><span>${c.name} x${c.qty}</span><span>₱${c.price * c.qty}</span></div>`).join('');

  $('success-msg').textContent = `Hi ${name}! Your ${orderType.replace('-', ' ')} order has been received.`;
  $('success-summary').innerHTML = `${itemLines}<div class="si-row si-total"><span>Total</span><span>₱${total}</span></div>`;

  cart = [];
  ['order-name', 'order-phone', 'order-address', 'order-notes'].forEach(id => { $(id).value = ''; });
  goToStep(4);
}

// ─── OPEN / CLOSE ────────────────────────────────────────────────────────────
function openModal() {
  lastFocus = document.activeElement;
  $('order-modal').classList.add('active');
  document.body.style.overflow = 'hidden';
  goToStep(1);
  $('modal-close').focus();
}

function closeModal() {
  $('order-modal').classList.remove('active');
  document.body.style.overflow = '';
  if (lastFocus && lastFocus.focus) lastFocus.focus();
}

// ─── INIT ────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  createModal();

  // open modal triggers (nav button, "Order" link, "Order Online", "Order Now")
  document.querySelector('.nav-cta').addEventListener('click', openModal);
  document.querySelectorAll('a[href="#order"], .btn-dark').forEach(btn => {
    btn.addEventListener('click', (e) => { e.preventDefault(); openModal(); });
  });

  $('modal-close').addEventListener('click', closeModal);
  $('modal-backdrop').addEventListener('click', closeModal);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && $('order-modal').classList.contains('active')) closeModal();
  });

  // quantity buttons (event delegation, so they survive re-renders)
  $('modal-menu-grid').addEventListener('click', (e) => {
    const b = e.target.closest('.qty-btn');
    if (!b) return;
    const id = parseInt(b.dataset.id, 10);
    changeQty(id, b.classList.contains('plus') ? 1 : -1);
    updateQtyDisplay(id);
  });
  $('modal-cart').addEventListener('click', (e) => {
    const b = e.target.closest('.qty-btn');
    if (!b) return;
    changeQty(parseInt(b.dataset.id, 10), b.classList.contains('plus') ? 1 : -1);
    renderCart();
  });

  $('btn-next').addEventListener('click', () => {
    if (currentStep === 1) {
      if (cart.length === 0) { alert('Please add at least one item to your cart.'); return; }
      goToStep(2);
    } else if (currentStep === 2) {
      if (cart.length === 0) { alert('Your cart is empty.'); return; }
      goToStep(3);
    } else if (currentStep === 3) {
      placeOrder();
    }
  });
  $('btn-back').addEventListener('click', () => { if (currentStep > 1) goToStep(currentStep - 1); });
  $('btn-close-success').addEventListener('click', closeModal);

  document.querySelectorAll('.type-btn').forEach(b => {
    b.addEventListener('click', () => {
      document.querySelectorAll('.type-btn').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      orderType = b.dataset.type;
      $('address-group').style.display = orderType === 'delivery' ? 'flex' : 'none';
    });
  });

  // ── page scripts ───────────────────────────────────────────────────────────

  // Scroll reveal. After the reveal finishes, drop the stagger delay so hover effects feel instant.
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      el.classList.add('visible');
      observer.unobserve(el);
      setTimeout(() => { el.style.transitionDelay = '0s'; el.classList.add('settled'); }, 1000);
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right').forEach(el => observer.observe(el));

  // Link each menu card to its data, and make the "+" buttons really add to the cart
  document.querySelectorAll('.menu-card').forEach(card => {
    const name = card.querySelector('h3').textContent.trim();
    const item = menuItems.find(m => m.name === name);
    if (!item) return;
    card.dataset.id = item.id;
    card.dataset.cat = item.cat;
  });

  document.querySelectorAll('.add-btn').forEach(btn => {
    btn.setAttribute('aria-label', 'Add to order');
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      const id = parseInt(this.closest('.menu-card').dataset.id, 10);
      if (id) changeQty(id, 1);
      this.textContent = '✓';
      this.style.background = '#3d7a52';
      this.style.color = 'white';
      clearTimeout(this._t);
      this._t = setTimeout(() => { this.textContent = '+'; this.style.background = ''; this.style.color = ''; }, 1200);
    });
  });

  // Menu tabs: add an "All" tab and make the tabs actually filter
  const tabWrap = document.querySelector('.menu-tabs');
  const allTab = document.createElement('button');
  allTab.className = 'tab active';
  allTab.textContent = 'All';
  tabWrap.prepend(allTab);
  tabWrap.querySelectorAll('.tab').forEach(t => { if (t !== allTab) t.classList.remove('active'); });

  const tabCat = { 'all': 'all', 'espresso': 'espresso', 'cold brew': 'cold', 'seasonal': 'seasonal' };
  const tabs = tabWrap.querySelectorAll('.tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const cat = tabCat[tab.textContent.trim().toLowerCase()];
      document.querySelectorAll('.menu-card').forEach(card => {
        card.hidden = !(cat === 'all' || card.dataset.cat === cat);
      });
    });
  });

  // Nav shrink on scroll (class-based so the mobile padding isn't overridden)
  const nav = document.querySelector('nav');
  const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 60);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Highlight today's opening hours
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const today = days[new Date().getDay()];
  document.querySelectorAll('.hours-row').forEach(row => {
    row.classList.remove('today');
    const day = row.querySelector('.day');
    if (day.textContent.trim().startsWith(today)) {
      row.classList.add('today');
      if (!row.querySelector('.today-badge')) {
        const badge = document.createElement('span');
        badge.className = 'today-badge';
        badge.textContent = 'Today';
        day.appendChild(badge);
      }
    }
  });

  // "Get Directions" opens in a new tab
  document.querySelectorAll('a[href^="https://maps.google.com"]').forEach(a => { a.target = '_blank'; a.rel = 'noopener'; });

  // Broken image fallback (solid green block instead of a broken-image icon)
  const fallback = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='4' height='3'%3E%3Crect width='4' height='3' fill='%232d5a3d'/%3E%3C/svg%3E";
  const patch = (img) => { if (img.dataset.failed) return; img.dataset.failed = '1'; img.src = fallback; };
  const watch = (img) => {
    img.addEventListener('error', () => patch(img));
    if (img.complete && img.naturalWidth === 0 && img.src) patch(img);
  };
  document.querySelectorAll('img').forEach(watch);
  new MutationObserver(muts => muts.forEach(m => m.addedNodes.forEach(n => {
    if (n.nodeType !== 1) return;
    if (n.tagName === 'IMG') watch(n);
    n.querySelectorAll && n.querySelectorAll('img').forEach(watch);
  }))).observe(document.body, { childList: true, subtree: true });
});
